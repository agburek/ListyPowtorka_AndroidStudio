package com.example.listypowtorka;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Zadania> wszystkieZadania = new ArrayList<>();
    private ListView listView;
    private EditText editText;
    private Button button;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        wszystkieZadania.add( new Zadania("Zrobić pranie"));
        wszystkieZadania.add( new Zadania("Nauczyć się na sprawdzian"));
        wszystkieZadania.add( new Zadania("Zrobić zakupy"));
        wszystkieZadania.add( new Zadania("Posprzątać w pokoju"));

        listView = findViewById(R.id.listView);
        editText = findViewById(R.id.editText);
        button = findViewById(R.id.button);

        ArrayAdapter<Zadania> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                wszystkieZadania
        );

        listView.setAdapter(adapter);
        listView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        view.setBackgroundColor(Color.RED);
                    }
                }
        );

        button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String zad = editText.getText().toString();
                        wszystkieZadania.add(new Zadania(zad));
                        adapter.notifyDataSetChanged();
                    }
                }
        );
    }
}